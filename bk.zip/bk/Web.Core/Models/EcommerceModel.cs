﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Web.Core.Models
{
    public class EcommerceModel
    {
        public User UserInfo { get; set; }
        public List<Product> ProductList { get; set; }
    }
}
