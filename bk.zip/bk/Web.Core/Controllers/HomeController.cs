﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Web.Core.Models;
using System.Net.Http;
using Newtonsoft.Json;

namespace Web.Core.Controllers
{
   
    public class HomeController : Controller
    {
        public static string PRODUCT_API_URL = "http://localhost:6001/api";
        public static string USER_API_URL = "http://localhost:6002/api";
        public async Task<IActionResult> Index()
        {
            HttpClient client = new HttpClient();
            HttpResponseMessage resp1 = await client.GetAsync($"{USER_API_URL}/users");
            // For the user data
            var user = new User();
            if (resp1.IsSuccessStatusCode)
            {
                var result = resp1.Content.ReadAsStringAsync().Result;
                user = JsonConvert.DeserializeObject<User>(result);
            }

            // for the product
            var products = new List<Product>();
            HttpResponseMessage res2 = await client.GetAsync($"{PRODUCT_API_URL}/products");
            if (res2.IsSuccessStatusCode)
            {
                var result = res2.Content.ReadAsStringAsync().Result;
                products = JsonConvert.DeserializeObject<List<Product>>(result);
            }

            var ecom = new EcommerceModel()
            {
                UserInfo = user,
                ProductList = products
            };
            return View(ecom);
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
