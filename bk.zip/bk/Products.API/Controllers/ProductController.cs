﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Products.API.Models;

namespace Products.API.Controllers
{
    [Route("api/products")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<Product>> Get()
        {
            List<Models.Product> lst = new List<Product>();
            lst.Add(new Product() { Id = 1, ProductName = "Product1", Price = 10 });
            lst.Add(new Product() { Id = 2, ProductName = "Product2", Price = 140 });
            lst.Add(new Product() { Id = 3, ProductName = "Product3", Price = 105 });
            lst.Add(new Product() { Id = 4, ProductName = "Product4", Price = 140 });
            return lst;
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<string> Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
